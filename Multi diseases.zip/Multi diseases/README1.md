# sepsis-prediction--machine-learning

predicting the various stages of sepsis by using the symptoms of the patient(using flask framework)
